package com.example.user.calculatorcb15;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView input, result;
    Button one, two, three, four, five, six, seven, eight, nine, zero, add, minus, multi, divide, equal, clear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = (TextView)findViewById(R.id.tVinput);
        result = (TextView)findViewById(R.id.tVresult);

        //--------------------------------------- BUTTON CONFIGURATION ---------------------------------------

        zero = (Button)findViewById(R.id.btn0);
        zero.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "0");
            }
        });

        one = (Button)findViewById(R.id.btn1);
        one.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "1");
            }
        });

        two = (Button)findViewById(R.id.btn2);
        two.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "2");
            }
        });

        three = (Button)findViewById(R.id.btn3);
        three.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "3");
            }
        });

        four = (Button)findViewById(R.id.btn4);
        four.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "4");
            }
        });

        five = (Button)findViewById(R.id.btn5);
        five.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "5");
            }
        });

        six = (Button)findViewById(R.id.btn6);
        six.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "6");
            }
        });

        seven = (Button)findViewById(R.id.btn7);
        seven.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "7");
            }
        });

        eight = (Button)findViewById(R.id.btn8);
        eight.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "8");
            }
        });

        nine = (Button)findViewById(R.id.btn9);
        nine.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                input.setText(input.getText() + "9");
            }
        });

        add = (Button)findViewById(R.id.btnAdd);
        minus = (Button)findViewById(R.id.btnMinus);
        multi = (Button)findViewById(R.id.btnMulti);
        divide = (Button)findViewById(R.id.btnDivide);
        equal = (Button)findViewById(R.id.btnEqual);
        clear = (Button)findViewById(R.id.btnClear);


    }

    public void Addition(View view){
        String latestInput = input.getText().toString();
        String lastChar = latestInput.substring(latestInput.length()-1);

        if(latestInput != "" && lastChar != "+" && lastChar != "-" && lastChar != "*" && lastChar != "/")
        {
            input.setText(input.getText() + "+");
        }
    }


}
